///////////////////////////////////////////////////////////
//  FixedRebate.cpp
//  Implementation of the Class FixedRebate
//  Created on:      10-mars-2020 16:01:16
//  Original author: francois
///////////////////////////////////////////////////////////

#include "FixedRebate.h"

namespace PolyCharge
{
	FixedRebate::FixedRebate(AbsSubscriptionPlan& plan, float percent)
		: AbsRebateDecorator(plan), m_percent(percent)
	{

	}
	
	void FixedRebate::accept(AbsSubscriptionPlanVisitor& vis) {
		vis.processFixedRebate(*this);
	}
	
	Amount FixedRebate::computeCost(kWh charge) const {
		
		Amount reducedCost = m_plan.computeCost(charge) - ((m_plan.computeCost(charge) - m_plan.getSubscriptionCost()) * m_percent);
		return  reducedCost;
	}
	
	Amount FixedRebate::computeMarginalCost(kWh purchasedEnergy, kWh extraEnergy) const {
		
		Amount rebateCost = m_plan.computeMarginalCost(purchasedEnergy, extraEnergy);
		if (purchasedEnergy == 0) {
			rebateCost = (rebateCost - getSubscriptionCost()) * (1 - m_percent);
			rebateCost+= getSubscriptionCost();
		}
		else {
			rebateCost *= (1 - m_percent);
		}
		return rebateCost; 
	}

	float FixedRebate::getRebatePercent() const
	{
		
		return m_percent;
	}
	void FixedRebate::setRebatePercent(float percent)
	{
		
		percent = m_percent; 
	}
}